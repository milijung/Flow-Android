package com.example.client.ui.home

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.client.R

class HomeListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_list)
    }
}