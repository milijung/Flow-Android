package com.example.client.data.model

import android.graphics.Bitmap
import android.telecom.Call
import androidx.room.Query

data class CalendarData(
    val day:String,
    val expense:String="",
    val income:String=""
)






