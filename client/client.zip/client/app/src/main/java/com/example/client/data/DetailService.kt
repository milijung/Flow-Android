package com.example.client.data

import com.example.client.data.model.ResponseData
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Path

interface DetailService {
    @POST("/details/{userId}")
    fun insertDetail(
        @Path("userId") userId:Int,
        @Body detailRequest : Detail,
    ): Call<ResponseData>
}